package com.xinzone.entity;

/**
 * @ClassName:EmployeeEntity
 * @Description:
 * @Author:YangYushuo
 * @Date:2018/10/23 20:18
 * @Version:1.0
 */
public class EmployeeEntity {
    //员工共id
    private Integer id;
    //员工年龄
    private Integer age;
    //员工姓名
    private String employeeName;
    //员工性别
    private String sex;
    //员工住址
    private String address;
    //员工岗位
    private String job;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    @Override
    public String toString() {
        return "EmployeeEntity{" +
                "id=" + id +
                ", age=" + age +
                ", employeeName='" + employeeName + '\'' +
                ", sex='" + sex + '\'' +
                ", address='" + address + '\'' +
                ", job='" + job + '\'' +
                '}';
    }

    public EmployeeEntity(Integer id, Integer age, String employeeName, String sex, String address, String job) {
        this.id = id;
        this.age = age;
        this.employeeName = employeeName;
        this.sex = sex;
        this.address = address;
        this.job = job;
    }

    public EmployeeEntity(Integer age, String employeeName, String sex, String address, String job) {
        this.age = age;
        this.employeeName = employeeName;
        this.sex = sex;
        this.address = address;
        this.job = job;
    }

    public EmployeeEntity() {
    }
}
