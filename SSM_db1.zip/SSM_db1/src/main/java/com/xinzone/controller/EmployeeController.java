package com.xinzone.controller;

import com.base.bean.AjaxJson;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.xinzone.entity.EmployeeEntity;
import com.xinzone.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @ClassName:EmployeeController
 * @Description:Controller
 * @Author:YangYushuo
 * @Date:2018/10/24 9:58
 * @Version:1.0
 */
@Controller
@RequestMapping("/employeeEntity")
public class EmployeeController {
    //每页的条数
    private static final Integer PAGESIZE = 5;
    @Autowired
    private IEmployeeService employeeService;

    /**
     * 获取所有员工列表
     *
     * @param request
     * @param model
     * @param pageNo  当前页
     */
    @RequestMapping("/getAllEmployee")
    public String getAllEmployee(HttpServletRequest request, Model model,
                                 @RequestParam(defaultValue = "1", required = true, value = "pageNo"
                                 ) Integer pageNo) {
        //开始分页，先分页，后查询，否则pageSize会出错
        PageHelper.startPage(pageNo, PAGESIZE);
        List<EmployeeEntity> list = employeeService.getAllEmployee();
        PageInfo<EmployeeEntity> pageInfo = new PageInfo<EmployeeEntity>(list);
        model.addAttribute("pageInfo", pageInfo);
        return "/allEmployee";
    }

    /**
     * 跳转到添加员工页面
     *
     * @param request
     * @return
     */
    @RequestMapping("/toAddEmployee")
    public String toAddEmployee(HttpServletRequest request) {
        return "/addEmployee";
    }

    /**
     * 添加员工并重定向
     *
     * @param employeeEntity
     * @param model
     * @return
     */
    @RequestMapping("/addEmployee")
    public String addEmployee(EmployeeEntity employeeEntity, Model model) {
        employeeService.insertEmployee(employeeEntity);
        return "redirect:/employeeEntity/getAllEmployee";
    }

    /**
     * 编辑员工信息并重定向
     *
     * @param employeeEntity
     * @param request
     * @param model
     * @return
     */
    @RequestMapping("/updateEmployee")
    public String updateEmployee(EmployeeEntity employeeEntity, HttpServletRequest request, Model model, Integer pageNo) {
        if (employeeService.updateEmployee(employeeEntity)) {
            employeeEntity = employeeService.getEmployeeById(employeeEntity.getId());
            model.addAttribute("employee", employeeEntity);
            return "redirect:/employeeEntity/getAllEmployee";
        } else {
            return "/error";
        }
    }

    /**
     * 按照id查询Employee信息
     *
     * @param id
     * @param request
     * @param model
     * @return
     */
    @RequestMapping("/getEmployee")
    public String getEmployeeById(Integer id, HttpServletRequest request, Model model) {
        model.addAttribute("employeeEntity", employeeService.getEmployeeById(id));
        return "/editEmployee";
    }


    /**
     * 删除员工
     * @param id
     * @return
     */
    @RequestMapping("/deleteEmployee")
    @ResponseBody
    public AjaxJson deleteEmployee( @RequestBody String id) {
        AjaxJson ajaxJson = new AjaxJson();
        boolean b = employeeService.deleteEmployee(Integer.parseInt(id.split("=")[1]));
        if(b){
            ajaxJson.setCode(200);
            ajaxJson.setMsg("刪除成功");
        }else {
            ajaxJson.setMsg("刪除失敗");
            ajaxJson.setCode(400);
        }
        return ajaxJson;
    }

}
