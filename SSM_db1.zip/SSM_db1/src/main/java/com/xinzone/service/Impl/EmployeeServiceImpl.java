package com.xinzone.service.Impl;

import com.xinzone.dao.IEmployeeMapper;
import com.xinzone.entity.EmployeeEntity;
import com.xinzone.service.IEmployeeService;
import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * @ClassName:EmployeeServiceImpl
 * @Description:
 * @Author:YangYushuo
 * @Date:2018/10/23 21:35
 * @Version:1.0
 */
@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
    private static Logger log = LogManager.getLogger(EmployeeServiceImpl.class);
    @Autowired
    private IEmployeeMapper employeeMapper;

    /**
     * 插入一条数据
     *
     * @param employeeEntity
     */
    @Override
    public void insertEmployee(EmployeeEntity employeeEntity) {
        try {
            employeeMapper.insertEmployee(employeeEntity);
            log.info("插入了一条数据");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage() + "数据插入错误");
        }

    }

    /**
     * 更新数据
     *
     * @param employeeEntity
     * @return
     */
    @Override
    public boolean updateEmployee(EmployeeEntity employeeEntity) {
        Boolean updateResult = false;
        try {
            updateResult = employeeMapper.updateEmployee(employeeEntity);
            if (updateResult) {
                log.info("更新了一条数据" + employeeEntity.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage() + "数据更新错误");
        } finally {
            return updateResult;
        }

    }

    /**
     * 删除一条数据
     *
     * @param id
     * @return
     */
    @Override
    public boolean deleteEmployee(int id) {
        Boolean deleteResult = false;
        try {
            deleteResult = employeeMapper.deleteEmployee(id);
            if (deleteResult) {
                log.info("删除了一条数据" + ":  id=" + id);
            } else {
                log.info("删除数据失败" + ":  id=" + id);
            }
        } catch (Exception e) {
            log.error(e.getMessage() + "数据删除失败: " + "id=" + id);
            e.printStackTrace();
        } finally {
            return deleteResult;
        }

    }

    /**
     * 查找一条数据
     *
     * @param id
     * @return
     */
    @Override
    public EmployeeEntity getEmployeeById(int id) {
        EmployeeEntity employeeEntity = null;
        try {
            employeeEntity = employeeMapper.getEmployeeById(id);
            log.info("查找一条数据" + "id=" + id);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage() + "数据查找错误：id=" + id);
        } finally {
            return employeeEntity;
        }

    }

    /**
     * 查询所有数据
     *
     * @return
     */
    @Override
    public List<EmployeeEntity> getAllEmployee() {
        List<EmployeeEntity> listAll = null;
        try {
            listAll = employeeMapper.getAllEmployee();
            log.info("查询所有数据");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage() + "职工信息查询错误！");
        } finally {
            return listAll;
        }


    }
}