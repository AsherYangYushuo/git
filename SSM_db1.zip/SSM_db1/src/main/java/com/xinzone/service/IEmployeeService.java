package com.xinzone.service;

import com.xinzone.entity.EmployeeEntity;

import java.util.List;

/**
 * @InterfaceName:IEmployeeService
 * @Description:
 * @Author:YangYushuo
 * @Date:2018/10/23 21:31
 * @Version:1.0
 */

public interface IEmployeeService {
    /**
     * 新增员工信息
     */
    void insertEmployee(EmployeeEntity employeeEntity);

    /**
     * 更新员工信息
     */
    boolean updateEmployee(EmployeeEntity employeeEntity);

    /**
     * 删除员工信息
     */
    boolean deleteEmployee(int id);

    /**
     * 按照员工ID查询员工信息
     */
    EmployeeEntity getEmployeeById(int id);

    /**
     * 查询所有员工信息
     */
    List<EmployeeEntity> getAllEmployee();
}
