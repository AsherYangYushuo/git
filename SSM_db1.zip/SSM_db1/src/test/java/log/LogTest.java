package log;

import com.xinzone.entity.EmployeeEntity;
import com.xinzone.service.IEmployeeService;
import com.xinzone.service.Impl.EmployeeServiceImpl;
import org.junit.Test;

/**
 * @ClassName:LogTest
 * @Description:
 * @Author:YangYushuo
 * @Date:2018/10/24 11:20
 * @Version:1.0
 */
public class LogTest {

    @Test
   public void LoggerTest(){
        IEmployeeService employeeService=new EmployeeServiceImpl();
        EmployeeEntity employeeEntity1 =new EmployeeEntity( 25, "wangwu", "男", "北京丰台", "产品经理" );
        EmployeeEntity employeeEntity2 =new EmployeeEntity( 24, "zhaoliu", "男", "北京丰台", "产品经理" );
        //增加数据
        employeeService.insertEmployee(employeeEntity1);
        //删除数据
        employeeService.deleteEmployee(5);
        //查找数据
        employeeService.getEmployeeById(2);
        //更新数据
        employeeService.updateEmployee(employeeEntity2);

   }
}
